package org.matheclipse.generic.interfaces;

public interface IArrayFunction<T> {
	T evaluate(Object[] index);
}
