package org.matheclipse.generic.util;

/**
 * Marker interface for nested list elements. I.e. for list elements which could
 * be lists by themselves.
 */
public interface IElement {

}
