package org.matheclipse.generic.interfaces;

public interface IIndexFunction<T> {
	T evaluate(int[] index);
}
