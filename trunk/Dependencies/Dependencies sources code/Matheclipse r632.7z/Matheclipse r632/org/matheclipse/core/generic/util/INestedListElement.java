package org.matheclipse.core.generic.util;

/**
 * Interface for INestedList elements. I.e. for list elements which could also contain
 * lists
 */
public interface INestedListElement {

}
