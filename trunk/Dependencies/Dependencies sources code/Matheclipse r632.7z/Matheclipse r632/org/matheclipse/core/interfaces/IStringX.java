package org.matheclipse.core.interfaces;

/**
 *  (I)nterface for a (String) e(X)pression
 * 
 */
public interface IStringX extends IExpr {

}
