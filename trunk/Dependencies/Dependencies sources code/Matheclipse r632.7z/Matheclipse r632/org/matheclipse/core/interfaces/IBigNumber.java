package org.matheclipse.core.interfaces;

/**
 * 
 * Implemented by all "exact" number interfaces (i.e. IInteger IFraction, IComplex)
 * 
 *
 */
public interface IBigNumber extends INumber {

}
